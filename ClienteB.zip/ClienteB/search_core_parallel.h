// search_core_parallel.h
#pragma once
#include <string>
#include <vector>

struct Review {
    int         id;
    std::string productId;
    std::string userId;
    int         score;
    long long   time;
};

std::vector<Review> cargar_csv_amazon(const std::string& filename);

long buscar_por_productId_parallel(
    const std::vector<Review>& data,
    const std::string& objetivo,
    int numThreads
);
