// cliente_secuencial.cpp
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")

#include <iostream>
#include <fstream>
#include <vector>
#include <chrono>

#include "search_core_seq.h"

// ========================
// Configuración
// ========================
static const char* SERVER_IP = "172.17.42.153";  // IP servidor
static const int   SERVER_PORT = 5000;

bool recv_file(SOCKET sock, const std::string& outFile) {
    std::ofstream out(outFile, std::ios::binary);
    if (!out.is_open()) return false;

    char buffer[4096];
    int bytesRead;

    while ((bytesRead = recv(sock, buffer, sizeof(buffer), 0)) > 0) {
        out.write(buffer, bytesRead);
        if (bytesRead < sizeof(buffer)) break;
    }

    out.close();
    return true;
}

int main() {
    std::string file    = "reviews_300k.csv";
    std::string objetivo = "B001E4KFG0";

    std::cout << "========================================\n";
    std::cout << "   Experimento de Busqueda en CSV (CLIENTE SECUENCIAL)\n";
    std::cout << "   Archivo  : " << file << "\n";
    std::cout << "   Producto : " << objetivo << "\n";
    std::cout << "   Servidor : " << SERVER_IP << ":" << SERVER_PORT << "\n";
    std::cout << "========================================\n\n";

    // 1. WinSock
    WSADATA wsa;
    WSAStartup(MAKEWORD(2, 2), &wsa);

    SOCKET s = socket(AF_INET, SOCK_STREAM, 0);

    sockaddr_in srv{};
    srv.sin_family = AF_INET;
    srv.sin_port   = htons(SERVER_PORT);
    inet_pton(AF_INET, SERVER_IP, &srv.sin_addr);

    std::cout << "Conectando al servidor...\n";

    if (connect(s, (sockaddr*)&srv, sizeof(srv)) == SOCKET_ERROR) {
        std::cerr << "ERROR: No se pudo conectar al servidor.\n";
        return 1;
    }

    // 2. Descargar archivo
    std::cout << "Solicitando archivo '" << file << "'...\n";

    std::string cmd = "GET " + file + "\n";
    send(s, cmd.c_str(), (int)cmd.size(), 0);

    auto t_down_1 = std::chrono::high_resolution_clock::now();
    recv_file(s, file);
    auto t_down_2 = std::chrono::high_resolution_clock::now();

    closesocket(s);
    WSACleanup();

    double tiempo_descarga =
        std::chrono::duration<double, std::milli>(t_down_2 - t_down_1).count();

    std::cout << "Archivo recibido correctamente.\n";
    std::cout << "Tiempo de descarga (ms): " << tiempo_descarga << "\n\n";

    // 3. Cargar CSV
    std::cout << "Cargando dataset...\n";

    auto t_load_1 = std::chrono::high_resolution_clock::now();
    auto data     = cargar_csv_amazon(file);
    auto t_load_2 = std::chrono::high_resolution_clock::now();

    double tiempo_carga =
        std::chrono::duration<double, std::milli>(t_load_2 - t_load_1).count();

    std::cout << "Registros cargados: " << data.size() << "\n";
    std::cout << "Tiempo de carga (ms): " << tiempo_carga << "\n\n";

    // 4. Búsqueda SECUENCIAL
    std::cout << "Ejecutando búsqueda SECUENCIAL...\n";

    auto t1 = std::chrono::high_resolution_clock::now();
    long encontrados = buscar_por_productId_secuencial(data, objetivo);
    auto t2 = std::chrono::high_resolution_clock::now();

    double tiempo_secuencial =
        std::chrono::duration<double, std::milli>(t2 - t1).count();

    // 5. Resultados
    std::cout << "\nResultados:\n";
    std::cout << "  Coincidencias         : " << encontrados << "\n";
    std::cout << "  Tiempo descarga (ms)   : " << tiempo_descarga << "\n";
    std::cout << "  Tiempo carga (ms)      : " << tiempo_carga << "\n";
    std::cout << "  Tiempo secuencial (ms) : " << tiempo_secuencial << "\n";
    std::cout << "========================================\n";

    return 0;
}
