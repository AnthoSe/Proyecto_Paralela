// search_core_seq.h
#pragma once
#include <string>
#include <vector>

struct Review {
    int         id;
    std::string productId;
    std::string userId;
    int         score;
    long long   time;
};

std::vector<Review> cargar_csv_amazon(const std::string& filename);

long buscar_por_productId_secuencial(
    const std::vector<Review>& data,
    const std::string& objetivo
);
