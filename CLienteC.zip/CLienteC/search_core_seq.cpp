// search_core_seq.cpp
#include "search_core_seq.h"

#include <fstream>
#include <sstream>
#include <iostream>

static bool parse_line_amazon(const std::string& line, Review& r) {
    std::stringstream ss(line);

    std::string idStr;
    std::string productId;
    std::string userId;
    std::string profileName;
    std::string helpNum, helpDen;
    std::string scoreStr;
    std::string timeStr;

    if (!std::getline(ss, idStr, ','))       return false;
    if (!std::getline(ss, productId, ','))   return false;
    if (!std::getline(ss, userId, ','))      return false;
    if (!std::getline(ss, profileName, ',')) return false;
    if (!std::getline(ss, helpNum, ','))     return false;
    if (!std::getline(ss, helpDen, ','))     return false;
    if (!std::getline(ss, scoreStr, ','))    return false;
    if (!std::getline(ss, timeStr, ','))     return false;

    try {
        r.id        = std::stoi(idStr);
        r.productId = productId;
        r.userId    = userId;
        r.score     = std::stoi(scoreStr);
        r.time      = std::stoll(timeStr);
    }
    catch (...) {
        return false;
    }

    return true;
}

std::vector<Review> cargar_csv_amazon(const std::string& filename) {
    std::vector<Review> data;
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "No se pudo abrir el archivo: " << filename << "\n";
        return data;
    }

    std::string line;
    bool first = true;
    while (std::getline(file, line)) {
        if (first) { first = false; continue; }
        if (line.empty()) continue;

        Review r;
        if (parse_line_amazon(line, r)) {
            data.push_back(r);
        }
    }
    return data;
}

long buscar_por_productId_secuencial(
    const std::vector<Review>& data,
    const std::string& objetivo
) {
    long total = 0;
    for (const auto& r : data) {
        if (r.productId == objetivo) {
            total++;
        }
    }
    return total;
}
